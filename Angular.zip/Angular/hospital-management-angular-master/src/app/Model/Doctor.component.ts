export class doctor {
    // pkUseId: number;
    
    doctorContactno: String;
    doctorName: String;
    doctorDegree: String;
    
    doctorAddress: String;
    doctorSpecification: String;
    fkRoleId: number;
    doctorExperience: number;
   
    
}