export class user {
    pkUserId: number;
    userUsername: String;
    userPassword: String;
    userEmail: String;
    userPhonenumber: String;
    userFirstname: String;
    userLastname: String;
    userCity: String;
    userState: String;
    userStreet: String;
    userIsActive: number;
    userCreatedOn: String;
    userUpdatedOn: String;
    fkRoleId: number;
    userAge: number;
    patientHeight: number;
    patientWeight: number;
    patientBloodGroup: String;
}