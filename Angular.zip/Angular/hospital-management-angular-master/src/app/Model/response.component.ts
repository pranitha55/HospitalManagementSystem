import { user } from './User.component';

export class response{
    status : number;
    data : user;
}